print("Welcome To Kaun Banega Crorepati (KBC)")

#Questions
questions = ("In which year did \"Kaun Banega Crorepati\" first premiere in India?",
             "Who was the blind contestent who won 1cr in 2021",
             "Which Indian state is known as the \"Land of Five Rivers\"",
             "What is the chemical symbol for the element with atomic number 6",
             "What is the capital city of Australia?",
             "Who is the founder of Microsoft Corporation?",
             "What is the official language of Brazil?")

#Question Number
que_n = ("First",
         "Second",
         "Third",
         "Fourth",
         "Fifth",
         "Sixth",
         "Seventh")

#Price Money
price = ("5000",
         "10,000",
         "50,000",
         "1,00,000",
         "10,00,000",
         "80,00,000",
         "100,00,000")

#Options
options = [["1) 2003", "2) 2000", "3) 2005", "4) 2001"],
           ["1) Sunmeet Kaur", "2) Himani Bundela", "3) Prasenjit Sarkar", "4) Kavita Chawla"],
           ["1) Punjab", "2) Rajasthan", "3) Gujrat", "4) Maharastra"],
           ["1) Fe", "2) Hg", "3) Au", "4) C"],
           ["1) Sydney", "2) Canberra", "3) Melbourn", "4) Perth"],
           ["1) Mark Zuckerberg", "2) Steve Jobs", "3) Bill Gates", "4) Jeff Bezos"],
           ["1) Portuguese", "2) Italien", "3) French", "4) Spanish"]]

answers = ['2', '2', '1', '4', '2', '3', '1']





print(" ")
print("Your" , que_n[0], "Question is for", price[0])
print("Your Question is", questions[0])
print(options[0][0])
print(options[0][1])
print(options[0][2])
print(options[0][3])
a = input("Choose The Option (1, 2, 3, 4) : ")
if(a == answers[0]):
  print("Congratulation!!", "You have won ", price[0])
else:
  print("So Sorry But your answer is wrong")
  exit()




print(" ")
proceed = input("Proceed To Next Question (Yes/No)")
if(proceed == 'Yes' or proceed == 'Y' or proceed == 'yes' or proceed == 'y' ):
  pass
else:
  print("Thanks For Playing KBC!! Your money win be sent to account ASAP.")
  exit()




print(" ")
print("Your" , que_n[1], "Question is for", price[1])
print("Your Question is", questions[1])
print(options[1][0])
print(options[1][1])
print(options[1][2])
print(options[1][3])
a = input("Choose The Option (1, 2, 3, 4) : ")
if(a == answers[1]):
  print("Congratulation!!", "You have won ", price[1])
else:
  print("So Sorry But your answer is wrong")
  exit()




print(" ")
proceed = input("Proceed To Next Question (Yes/No)")
if(proceed == 'Yes' or proceed == 'Y' or proceed == 'yes' or proceed == 'y' ):
  pass
else:
  print("Thanks For Playing KBC!! Your money win be sent to account ASAP.")
  exit()




print(" ")
print("Your" , que_n[2], "Question is for", price[2])
print("Your Question is", questions[2])
print(options[2][0])
print(options[2][1])
print(options[2][2])
print(options[2][3])
a = input("Choose The Option (1, 2, 3, 4) : ")
if(a == answers[2]):
  print("Congratulation!!", "You have won ", price[2])
else:
  print("So Sorry But your answer is wrong")
  exit()




print(" ")
proceed = input("Proceed To Next Question (Yes/No)")
if(proceed == 'Yes' or proceed == 'Y' or proceed == 'yes' or proceed == 'y' ):
  pass
else:
  print("Thanks For Playing KBC!! Your money win be sent to account ASAP.")
  exit()




print(" ")
print("Your" , que_n[3], "Question is for", price[3])
print("Your Question is", questions[3])
print(options[3][0])
print(options[3][1])
print(options[3][2])
print(options[3][3])
a = input("Choose The Option (1, 2, 3, 4) : ")
if(a == answers[3]):
  print("Congratulation!!", "You have won ", price[3])
else:
  print("So Sorry But your answer is wrong")
  exit()




print(" ")
proceed = input("Proceed To Next Question (Yes/No)")
if(proceed == 'Yes' or proceed == 'Y' or proceed == 'yes' or proceed == 'y' ):
  pass
else:
  print("Thanks For Playing KBC!! Your money win be sent to account ASAP.")
  exit()




print(" ")
print("Your" , que_n[4], "Question is for", price[4])
print("Your Question is", questions[4])
print(options[4][0])
print(options[4][1])
print(options[4][2])
print(options[4][3])
a = input("Choose The Option (1, 2, 3, 4) : ")
if(a == answers[4]):
  print("Congratulation!!", "You have won ", price[4])
else:
  print("So Sorry But your answer is wrong")
  exit()




print(" ")
proceed = input("Proceed To Next Question (Yes/No)")
if(proceed == 'Yes' or proceed == 'Y' or proceed == 'yes' or proceed == 'y' ):
  pass
else:
  print("Thanks For Playing KBC!! Your money win be sent to account ASAP.")
  exit()




print(" ")
print("Your" , que_n[5], "Question is for", price[5])
print("Your Question is", questions[5])
print(options[5][0])
print(options[5][1])
print(options[5][2])
print(options[5][3])
a = input("Choose The Option (1, 2, 3, 4) : ")
if(a == answers[5]):
  print("Congratulation!!", "You have won ", price[5])
else:
  print("So Sorry But your answer is wrong")
  exit()




print(" ")
proceed = input("Proceed To Next Question (Yes/No)")
if(proceed == 'Yes' or proceed == 'Y' or proceed == 'yes' or proceed == 'y' ):
  pass
else:
  print("Thanks For Playing KBC!! Your money win be sent to account ASAP.")
  exit()




print(" ")
print("Your" , que_n[1], "Question is for", price[6])
print("Your Question is", questions[6])
print(options[6][0])
print(options[6][1])
print(options[6][2])
print(options[6][3])
a = input("Choose The Option (1, 2, 3, 4) : ")
if(a == answers[6]):
  print("Congratulation!!", "You have won ", price[6])
else:
  print("So Sorry But your answer is wrong")
  exit()