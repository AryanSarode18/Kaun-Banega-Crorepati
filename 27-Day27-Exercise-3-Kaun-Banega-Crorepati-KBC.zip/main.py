print("Welcome To Kaun Banega Crorepati (KBC)\n")

#Questions
questions = ("In which year did \"Kaun Banega Crorepati\" first premiere in India?",
             "Who was the blind contestent who won 1cr in 2021",
             "Which Indian state is known as the \"Land of Five Rivers\"",
             "What is the chemical symbol for the element with atomic number 6",
             "What is the capital city of Australia?",
             "Who is the founder of Microsoft Corporation?",
             "What is the official language of Brazil?")

#Question Number
que_n = ("First",
         "Second",
         "Third",
         "Fourth",
         "Fifth",
         "Sixth",
         "Seventh")

#Price Money
price = ("5000",
         "10,000",
         "50,000",
         "1,00,000",
         "10,00,000",
         "80,00,000",
         "100,00,000")

#Options
options = [["1) 2003", "2) 2000", "3) 2005", "4) 2001", "2"],
           ["1) Sunmeet Kaur", "2) Himani Bundela", "3) Prasenjit Sarkar", "4) Kavita Chawla", "2"],
           ["1) Punjab", "2) Rajasthan", "3) Gujrat", "4) Maharastra", "1"],
           ["1) Fe", "2) Hg", "3) Au", "4) C", "4"],
           ["1) Sydney", "2) Canberra", "3) Melbourn", "4) Perth", "2"],
           ["1) Mark Zuckerberg", "2) Steve Jobs", "3) Bill Gates", "4) Jeff Bezos", "3"],
           ["1) Portuguese", "2) Italien", "3) French", "4) Spanish", "1"]]

def correct():
  a = input("Do You Want To Move Ahead? (Y/N)")
  if(a == "y" or a == "Y"):
    print("next Question - ")
  else:
    print("Thanks For playing!! The money will be instantly transfered to your bank account")

for i in range(6):
  print("Your", que_n[i], "Question Is for", price[i])
  print(questions[i])
  print("Your Options are")
  print(options[i][0])
  print(options[i][1])
  print(options[i][2])
  print(options[i][3])
  ans = input("Enter Your Answer (1/2/3/4) ")
  if(ans == options[i][-1]):
    print("Congratulations!!! You have you won", price[i])
    correct()
  else:
    print("Oops!! Wrong Answer!! Better Luck Next Time")
    exit()

print("Your", que_n[-1], "Question Is for", price[-1])
print(questions[-1])
print("Your Options are")
print(options[-1][0])
print(options[-1][1])
print(options[-1][2])
print(options[-1][3])
ans = input("Enter Your Answer (1/2/3/4) ")
if(ans == options[-1][-1]):
  print("Congratulations!!! You have you won", price[-1], ".", "You have emerged victorious, proving your knowledge and wit in this question contest. Your exceptional performance has earned you the coveted title of champion. Your intelligence and dedication have been truly commendable. Continue to shine bright and inspire others with your brilliance. Remember, knowledge is a powerful tool, and you have shown the world just how mighty it can be. Well done!")
  correct()
else:
  print("Oops!! Wrong Answer!! Better Luck Next Time")
  exit()